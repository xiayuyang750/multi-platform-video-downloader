# Projects using NG

Here is a list of projects currently using, supporting or migrating to QuickJS-NG.
If you want yours to be listed here, please open a PR!

## [txiki.js](https://github.com/saghul/txiki.js)

A tiny JavaScript runtime.

## [radare2](https://github.com/radareorg/radare2)

Reverse engineering framework.

## [rquickjs](https://github.com/DelSkayn/rquickjs)

High level Rust bindings.

## [llrt](https://github.com/awslabs/llrt)

Lightweight JS runtime for serverless applications.

## [nx.js](https://github.com/TooTallNate/nx.js)

JavaScript runtime for Nintendo Switch homebrew applications.

## [quickjs-rusty](https://github.com/Icemic/quickjs-rusty)

Rust wrapper focus on embedding-ready and no-pain type conversion and interoperability. 

## [CSPro](https://github.com/csprousers/cspro)

CSPro incorporates the QuickJS-NG engine as its embedded JavaScript runtime for executing logic, complementing its own domain-specific language, CSPro Logic.

## [GodotJS](https://github.com/godotjs/GodotJS)

This project adds TypeScript/JavaScript support for Godot 4.x. It supports multiple javascript runtimes, including QuickJS-NG.

## [quickjs_es_runtime](https://github.com/HiRoFa/quickjs_es_runtime)

Rust wrapper with typescript, modules, promises, async/await and much more.

## [Lua jsregexp](https://github.com/kmarius/jsregexp)

JavaScript regular expressions for Lua.

## [Edbrowse](https://edbrowse.org)

A combination editor, web-browser, and mail client that is 100% text based.

## [go-quickjs-wasi-reactor](https://github.com/aperturerobotics/go-quickjs-wasi-reactor)

Go module that embeds QuickJS-NG compiled to WebAssembly using the WASI reactor model. Provides re-entrant execution via exported C API functions, a high-level Go API with wazero, non-blocking event loop control, and a command-line REPL.

## [js-quickjs-wasi-reactor](https://github.com/aperturerobotics/js-quickjs-wasi-reactor)

JavaScript/TypeScript harness for running QuickJS-NG in WASI reactor mode. Includes a browser-compatible WASI shim, virtual filesystem, custom I/O handlers, and non-blocking event loop integration for browser and Node.js/Bun environments.

## [quickjs.ml](https://github.com/ml-in-barcelona/quickjs.ml)

OCaml bindings to quickjs-ng. Exposing both low-level C library access (libregexp, libunicode, js_dtoa, js_atod, and cutils) and a high-level API mirroring JavaScript built-ins like RegExp, String, and Number.

## [Python quickjs-ng](https://github.com/genotrance/quickjs-ng)

Python bindings for quickjs-ng based on https://github.com/PetterS/quickjs.

## [Px](https://github.com/genotrance/px)

Proxy server using quickjs-ng for PAC file processing.

## [std::slop](https://github.com/hsaliak/std_slop)

A C++/SQL based Coding agent. It exposes a QuickJS-ng environment to the LLM. The Agent accomplishes all it's work through this QuickJS-NG based "control plane".

## [QuickBEAM](https://github.com/elixir-volt/quickbeam)

JavaScript runtime for the BEAM - Web APIs backed by OTP, native DOM, and a built-in TypeScript toolchain.

## [quickjs-go](https://github.com/buke/quickjs-go)

Golang bindings for QuickJS-NG using cgo

## [Nordstjernen](https://github.com/nordstjernen-web/nordstjernen)

Nordstjernen web browser.

## [quickjs-cpp](https://github.com/qr243vbi/quickjs-cpp)

Header only library for quickjs-ng with modern C++ interface (Archived).

## [NekoBox](https://github.com/qr243vbi/nekobox)

A lightweight proxy client, empowered by sing-box and thrift.

## [RongJS](https://github.com/LingXia-Dev/Rong)

A multi-engine JavaScript runtime and Rust embedding API with first-class QuickJS-NG support.

## [scriptc](https://github.com/vercel-labs/scriptc)

TypeScript-to-Native Compiler

## [Qbs](https://github.com/qbs/qbs)

Cross-platform build system. Uses QuickJS-NG as its JavaScript backend for evaluating project files.

## [Vayu](https://github.com/athrvk/vayu)

Open-source API client with a native C++ load-testing engine. Embeds QuickJS-NG to enable in-app scripting: pre-request and test scripts with a Postman-compatible `pm.*` API.

## [react-native-quickjs](https://github.com/react-native-quickjs/quickjs)

JSI runtime for React Native using QuickJS-NG. Replaces Hermes / JSC.

